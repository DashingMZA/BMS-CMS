// YouTube Money Calculator — slug must match plugin.json.
BMS.plugin("youtube-money-calculator", (root, ctx) => {
  const $ = (sel) => root.querySelector(sel);
  const $$ = (sel) => Array.from(root.querySelectorAll(sel));

  // --- Data: typical RPM ranges (USD, US-heavy long-form audience) ---------
  // [low, high] per 1,000 monetized views. Shorts handled separately.
  const NICHES = {
    finance:     { label: "Finance & Investing", rpm: [10, 30] },
    legal:       { label: "Legal & Insurance",   rpm: [8, 20] },
    realestate:  { label: "Real Estate",         rpm: [8, 22] },
    tech:        { label: "Tech & SaaS",         rpm: [4, 14] },
    education:   { label: "Education & How-To",  rpm: [4, 12] },
    health:      { label: "Health & Fitness",    rpm: [4, 12] },
    lifestyle:   { label: "Lifestyle & Vlogs",   rpm: [2.5, 8] },
    entertainment:{ label: "Entertainment",      rpm: [1.5, 8] },
    gaming:      { label: "Gaming & Esports",    rpm: [1.5, 6] },
  };
  const SHORTS_RPM = [0.03, 0.08];

  // Country multiplier vs a US audience (advertiser bid strength).
  const COUNTRIES = {
    us:   { label: "United States", mult: 1.0 },
    uk:   { label: "United Kingdom", mult: 0.85 },
    ca:   { label: "Canada", mult: 0.8 },
    au:   { label: "Australia", mult: 0.8 },
    de:   { label: "Germany", mult: 0.7 },
    fr:   { label: "France", mult: 0.65 },
    br:   { label: "Brazil", mult: 0.25 },
    id:   { label: "Indonesia", mult: 0.15 },
    ph:   { label: "Philippines", mult: 0.1 },
    in:   { label: "India", mult: 0.1 },
    pk:   { label: "Pakistan", mult: 0.067 },
    bd:   { label: "Bangladesh", mult: 0.067 },
  };

  // --- Setup ---------------------------------------------------------------
  const settings = ctx.settings || {};
  // `root` is the shadow root — set CSS vars on an element inside it.
  $(".ytc").style.setProperty("--accent", settings.accent || "#e11d48");

  const title = (ctx.attrs && ctx.attrs.title) || "YouTube Money Calculator";
  const subtitle = (ctx.attrs && ctx.attrs.subtitle) || "";
  $(".ytc-title").textContent = title;
  const subEl = $(".ytc-sub");
  if (subtitle) subEl.textContent = subtitle; else subEl.remove();

  const nicheSel = $('select[name="niche"]');
  const countrySel = $('select[name="country"]');
  for (const [key, n] of Object.entries(NICHES)) {
    const o = document.createElement("option");
    o.value = key;
    o.textContent = `${n.label} ($${n.rpm[0]}–$${n.rpm[1]} RPM)`;
    nicheSel.appendChild(o);
  }
  for (const [key, c] of Object.entries(COUNTRIES)) {
    const o = document.createElement("option");
    o.value = key;
    o.textContent = c.label;
    countrySel.appendChild(o);
  }

  const viewsInput = $('input[name="views"]');
  const adblockInput = $('input[name="adblock"]');
  const midrollInput = $('input[name="midroll"]');
  const shortsInput = $('input[name="shorts"]');

  if (settings.default_views) viewsInput.value = settings.default_views;
  if (settings.default_niche && NICHES[settings.default_niche]) nicheSel.value = settings.default_niche;
  if (settings.default_country && COUNTRIES[settings.default_country]) countrySel.value = settings.default_country;

  const fmt = (n) =>
    "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  function calc() {
    const views = Math.max(0, parseFloat(viewsInput.value) || 0);
    const adblock = Math.min(60, Math.max(0, parseFloat(adblockInput.value) || 0)) / 100;
    const midroll = midrollInput.checked && !shortsInput.checked;
    const isShorts = shortsInput.checked;

    const niche = NICHES[nicheSel.value] || NICHES.lifestyle;
    const country = COUNTRIES[countrySel.value] || COUNTRIES.us;

    const [rpmLo, rpmHi] = isShorts ? SHORTS_RPM : niche.rpm;
    const rpmMid = (rpmLo + rpmHi) / 2;
    const mult = country.mult;

    // Monetized views after ad blockers; mid-roll adds ~40% for 8+ min videos.
    const monetized = views * (1 - adblock) * (midroll ? 1.4 : 1);

    const daily = (monetized / 1000) * rpmMid * mult;
    const rpmUsed = rpmMid * mult;
    const lo = (monetized / 1000) * rpmLo * mult;
    const hi = (monetized / 1000) * rpmHi * mult;

    $('[data-out="daily"]').textContent = fmt(daily);
    $('[data-out="weekly"]').textContent = fmt(daily * 7);
    $('[data-out="monthly"]').textContent = fmt(daily * 30);
    $('[data-out="yearly"]').textContent = fmt(daily * 365);

    const kind = isShorts ? "Shorts" : `${niche.label}, ${country.label} audience`;
    $(".ytc-rpm").innerHTML =
      `RPM used: <b>${fmt(rpmUsed)}</b> <span>(${kind}, typical estimate)</span>`;
    $(".ytc-range").innerHTML =
      `Likely range for these views: <b>${fmt(lo)} – ${fmt(hi)}</b>`;

    $('[data-for="adblock"]').textContent = `${Math.round(adblock * 100)}%`;
  }

  ["input", "change"].forEach((ev) => {
    viewsInput.addEventListener(ev, calc);
    adblockInput.addEventListener(ev, calc);
    nicheSel.addEventListener(ev, calc);
    countrySel.addEventListener(ev, calc);
    midrollInput.addEventListener(ev, calc);
    shortsInput.addEventListener(ev, calc);
  });

  $$(".ytc-quick button").forEach((b) =>
    b.addEventListener("click", () => {
      viewsInput.value = b.dataset.views;
      calc();
    })
  );

  calc();
  return () => {};
});
